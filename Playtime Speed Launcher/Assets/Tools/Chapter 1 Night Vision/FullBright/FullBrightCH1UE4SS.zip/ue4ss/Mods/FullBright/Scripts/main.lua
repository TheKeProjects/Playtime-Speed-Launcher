local UEHelpers = require("UEHelpers")
local KSL = nil
local rutaConfig = "../../FullBright_Config.ini"

local function CargarConfiguracion(ruta)
    local config = { KeyUnlit = "K", KeyLit = "L" }
    local archivo = io.open(ruta, "r")
    
    if archivo then
        for linea in archivo:lines() do
            if not linea:match("^%s*[%;%#]") then
                local clave, valor = linea:match("^%s*([%w_]+)%s*=%s*([%w_]+)")
                if clave and valor then
                    config[clave] = valor
                end
            end
        end
        archivo:close()
    end
    return config
end

local misAjustes = CargarConfiguracion(rutaConfig)
local teclaUnlit = Key[misAjustes.KeyUnlit] or Key.K
local teclaLit = Key[misAjustes.KeyLit] or Key.L

local function EjecutarModo(cmd, mensaje)
    ExecuteInGameThread(function()
        local status, World = pcall(UEHelpers.GetWorld)
        if not status or not World or not World:IsValid() then
            World = FindFirstOf("World")
        end
        if not World or not World:IsValid() then return end

        if not KSL or not KSL:IsValid() then
            KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        end
        if KSL and KSL:IsValid() then
            pcall(function() KSL:ExecuteConsoleCommand(World, cmd, nil) end)
        end

        local actorFresco = FindFirstOf("ModActor_C")
        if actorFresco and actorFresco:IsValid() then
            pcall(function() actorFresco:MostrarTexto(mensaje) end)
        end
    end)
end

RegisterKeyBind(teclaUnlit, {}, function() EjecutarModo("prevviewmode", "UNLIT MODE") end)
RegisterKeyBind(teclaLit, {}, function() EjecutarModo("viewmode lit", "LIT MODE") end)