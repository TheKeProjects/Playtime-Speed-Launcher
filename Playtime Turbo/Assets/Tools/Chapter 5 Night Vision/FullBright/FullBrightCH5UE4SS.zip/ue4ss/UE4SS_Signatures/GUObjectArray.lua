function Register()
    return "48 8D 0D ?? ?? ?? ?? 48 8B 04 F7 48 8B 18 48 8B D3 E8 ?? ?? ?? ??"
end

function OnMatchFound(MatchAddress)
    local LeaInstr = MatchAddress
    local NextInstr = LeaInstr + 0x7
    local Offset = LeaInstr + 0x3
    local AddressLoaded = NextInstr + DerefToInt32(Offset)
    return AddressLoaded
end