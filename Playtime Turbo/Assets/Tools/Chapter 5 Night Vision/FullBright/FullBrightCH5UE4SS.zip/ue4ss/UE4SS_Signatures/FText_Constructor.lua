function Register()
    return "40 53 57 48 83 EC 38 48 89 6C 24 60 48 8B FA 48 89 74 24 68 48 8B D9 33 F6 4C 89 74 24 30 89 74 24 50 83 7A 08 01 7F 31 E8 03 13 00 00 48"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end