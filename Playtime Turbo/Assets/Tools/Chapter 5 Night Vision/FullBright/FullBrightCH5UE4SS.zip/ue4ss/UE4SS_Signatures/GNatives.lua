function Register()
    return "48 8D 05 ?? ?? ?? ?? B9 1F 00 00 00 0F 1F 40 00 66 0F 1F 84 00 00 00 00 00 48"
end

function OnMatchFound(MatchAddress)
    local LeaInstr = MatchAddress
    local NextInstr = LeaInstr + 0x7
    local Offset = LeaInstr + 0x3
    local AddressLoaded = NextInstr + DerefToInt32(Offset)
    return AddressLoaded
end