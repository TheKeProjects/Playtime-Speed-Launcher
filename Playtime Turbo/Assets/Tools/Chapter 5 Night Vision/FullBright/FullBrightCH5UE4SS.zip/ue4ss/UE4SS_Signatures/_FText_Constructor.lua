function Register()
    return "48 89 5C 24 10 48 89 6C 24 18 48 89 74 24 20 57 48 83 EC 20 33 ED 48 8B DA 48 89 29 48 8B F9 48 8B 02 48 89 01 48 89 2A"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end